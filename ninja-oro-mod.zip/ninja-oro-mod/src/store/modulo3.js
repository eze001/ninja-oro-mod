export default {
    getters:{
        conteo(state){
          return state.oro;
        },
        agenda(state) {
          return state.actividades;
        },
        cadena(state){
          return state.cadenaoro;
        },
      },
}