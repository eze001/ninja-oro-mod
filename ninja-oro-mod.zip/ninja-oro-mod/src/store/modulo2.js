export default {
mutations: {
    encontrar(state,lugar){
      var a=Math.random();
      var b=Math.random();
      var c=0;
      var ind=state.indice;
      if(a>=0.5){
        if(lugar=="granja"){
          c=10+Math.trunc(11*b);
          state.oro+=c;
          state.actividades[ind]="La granja te dio "+c+" de oro";
        }
        if(lugar=="cueva"){
          c=5+Math.trunc(6*b);
          state.oro+=c;
          state.actividades[ind]="La cueva te dio "+c+" de oro";
        }
        if(lugar=="casa"){
          c=2+Math.trunc(4*b);
          state.oro+=c;
          state.actividades[ind]="La casa te dio "+c+" de oro";
        }
        if(lugar=="casino"){
          c=Math.trunc(51*b);
          state.oro+=c;
          state.actividades[ind]="El casino te dio "+c+" de oro";
        }
        state.cadenaoro[ind]=1;
    }else{
        if(lugar=="granja"){
            c=10+Math.trunc(11*b);
            state.oro-=c;
            state.actividades[ind]="Perdiste en la granja "+c+" de oro";
        }
    if(lugar=="cueva"){
      c=5+Math.trunc(6*b);
      state.oro-=c;
      state.actividades[ind]="Perdiste en la cueva "+c+" de oro";
    }
    if(lugar=="casa"){
      c=2+Math.trunc(4*b);
      state.oro-=c;
      state.actividades[ind]="Perdiste en la casa "+c+" de oro";
    }
    if(lugar=="casino"){
      c=Math.trunc(51*b);
      state.oro-=c;
      state.actividades[ind]="Perdiste en el casino "+c+" de oro";
    }
    state.cadenaoro[ind]=-1;
  }
        state.indice++;
        }
    },
}