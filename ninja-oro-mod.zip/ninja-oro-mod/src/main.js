import Vue from 'vue'
import Vuex from 'vuex'
import App from './App.vue'

Vue.config.productionTip = false

Vue.use(Vuex)

import modulo1 from "./store/modulo1.js"
//import modulo2 from "./store/modulo2.js"
//import modulo3 from "./store/modulo3.js"

const store = new Vuex.Store({
  modules:{
    modulo1,
  }
})

new Vue({
  store,
  render: h => h(App),
}).$mount('#app')
